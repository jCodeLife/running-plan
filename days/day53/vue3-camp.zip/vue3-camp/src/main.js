import { createApp } from 'vue'
import App from './App.vue'
import './index.css'

createApp(App).mount('#app')


// 为啥这么玩，

// 响应式+虚拟dom+模板编译+组件化